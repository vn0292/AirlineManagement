export default class LoginModelClass
{
    id='';
    firstName='';
    lastName='';
    gender ='';
    contact='';
    password='';


    constructor(id,
    firstName,
    lastName,
    gender,
    contact,
    password)
    {
        this.id=id;
        this.firstName=firstName;
        this.lastName=lastName;
        this.gender=gender;
        this.contact=contact;
        this.password=password;

    }
}