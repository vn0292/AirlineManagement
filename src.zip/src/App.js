import react,{Component} from 'react';
import './App.css';
import "bootstrap/dist/css/bootstrap.min.css";
import 'animate.css'
import NavBar from './Components/NavBar'


import React from 'react';



function App() {


  return (
   <div><NavBar/></div>
  );
}

export default App;
